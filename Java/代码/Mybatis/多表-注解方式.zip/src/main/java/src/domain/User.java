package src.domain;

import lombok.Data;

import java.util.List;

@Data
public class User {
    private String uid;
    private String uname;

    private List<Order> orderList;
}