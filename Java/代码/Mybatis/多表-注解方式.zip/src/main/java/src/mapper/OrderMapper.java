package src.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;

import src.domain.Order;

public interface OrderMapper {
    // 查询指定的订单数据以及所属用户
    @Select("select * from `order` where oid = #{oid}")
    @Results(id = "orderMap", value = {
            @Result(property = "user", one = @One(select = "src.mapper.UserMapper.info"), column = "user_id")
    })
    public Order info(@Param("oid") Integer oid);

    // 查询指定用户的所有订单数据
    @Select("select * from `order` where user_id=#{uid}")
    // @ResultMap("orderMap")
    public List<Order> list(@Param("uid") Integer uid);
}
