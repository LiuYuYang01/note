package src.domain;

@lombok.Data
public class Order {
    private String oid;
    private Double price;
    private String userId;

    private User user;
}
