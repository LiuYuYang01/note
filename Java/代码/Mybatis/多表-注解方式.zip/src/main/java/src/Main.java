package src;

import org.apache.ibatis.session.SqlSession;

import src.domain.Order;
import src.domain.User;
import src.mapper.OrderMapper;
import src.mapper.UserMapper;
import src.utils.MybatisUtils;

import java.util.List;

public class Main {
    // 获取用户数据
    public void userInfo(Integer id) {
        SqlSession sqlSession = MybatisUtils.getSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        User userData = userMapper.info(id);
        System.out.println(userData);

        MybatisUtils.close(sqlSession);
    }

    // 获取用户列表
    public void userList() {
        SqlSession sqlSession = MybatisUtils.getSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        List<User> userList = userMapper.list();
        System.out.println(userList);

        MybatisUtils.close(sqlSession);
    }

    // 获取订单数据
    public void orderInfo(Integer id) {
        SqlSession sqlSession = MybatisUtils.getSession();
        OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);

        Order orderData = orderMapper.info(id);
        System.out.println(orderData);

        MybatisUtils.close(sqlSession);
    }

    // 获取订单列表
    public void orderList(Integer id) {
        SqlSession sqlSession = MybatisUtils.getSession();
        OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);

        List<Order> orderList = orderMapper.list(id);
        System.out.println(orderList);

        MybatisUtils.close(sqlSession);
    }
}
