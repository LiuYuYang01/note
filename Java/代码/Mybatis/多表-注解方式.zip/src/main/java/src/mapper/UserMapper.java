package src.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;

import src.domain.User;

public interface UserMapper {
    // 查询指定用户的全部订单数据
    @Select("select * from user where uid=#{uid}")
    @Results({
            @Result(property = "orderList", many =  @Many(select = "src.mapper.OrderMapper.list"), column = "uid")
    })
    public User info(@Param("uid") Integer uid);

    // 查询全部用户的全部订单数据
    @Select("select * from user")
    @Results({
            @Result(property = "uid", column = "uid"),
            @Result(property = "orderList", many =  @Many(select = "src.mapper.OrderMapper.list"), column = "uid")
    })
    public List<User> list();
}
