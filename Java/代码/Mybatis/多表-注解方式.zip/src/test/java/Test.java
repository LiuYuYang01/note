import src.Main;

public class Test {
    @org.junit.Test
    public void run(){
        Main m = new Main();

        // 查询指定用户的全部订单数据
        m.userInfo(1);
        // 查询全部用户的全部订单数据
        m.userList();

        // 查询指定订单的用户数据
        // m.orderInfo(2);
        // 查询全部订单的用户数据
        // m.orderList(1);
    }
}
