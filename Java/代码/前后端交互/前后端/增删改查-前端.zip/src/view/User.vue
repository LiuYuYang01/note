<script setup lang="ts">

</script>

<template>
  <h1>用户管理</h1>
</template>

<style scoped lang="scss">
</style>
