package src.service.impl;

import org.apache.ibatis.session.SqlSession;
import src.domain.User;
import src.mapper.UserMapper;
import src.service.UserService;
import src.utils.MybatisUtils;

public class UserServicelmpl implements UserService {
    public User info(Integer uid) {
        SqlSession sqlSession = MybatisUtils.getSession();

        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        User user = userMapper.info(uid);

        MybatisUtils.close(sqlSession);

        return user;
    }

    public void add(User user) {
        SqlSession sqlSession = MybatisUtils.getSession();

        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        Integer n = userMapper.add(user);
        System.out.println(n >= 1 ? "新增成功" : "新增失败");

        System.out.println(user.getUid());

        MybatisUtils.close(sqlSession);
    }
}
