package src.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import src.domain.User;

public interface UserMapper {
    @Select("select * from user where uid = #{uid}")
    public User info(Integer uid);

    @Options(keyProperty = "uid", useGeneratedKeys = true)
    @Insert("insert into user(uname) values(uname)")
    public Integer add(User user);
}
