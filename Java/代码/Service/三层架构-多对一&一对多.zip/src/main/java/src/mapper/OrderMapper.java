package src.mapper;

import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import src.domain.Order;

public interface OrderMapper {
    @Select("select * from `order` where oid = #{oid}")
    @Results({
            @Result(property = "userId", column = "user_id"),
            @Result(property = "user", one = @One(select = "src.mapper.UserMapper.info"), column = "user_id")
    })
    public Order info(Integer oid);
}
