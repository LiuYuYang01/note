package src.service;

import src.domain.Order;

public interface OrderService {
    public Order info(Integer oid);
}
