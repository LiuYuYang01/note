package src.service;

import src.domain.User;

public interface UserService {
    public User info(Integer uid);
    public void add(User user);
}
