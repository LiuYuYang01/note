package src.web;

import src.domain.Order;
import src.service.OrderService;
import src.service.impl.OrderServicelmpl;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import com.alibaba.fastjson.JSONObject;

@WebServlet("/order")
public class OrderServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 获取请求的oid
        Integer oid = Integer.valueOf(request.getParameter("oid"));

        OrderService orderService = new OrderServicelmpl();

        Order orderData =  orderService.info(oid);

        response.setContentType("application/json; charset=utf8");

        PrintWriter out = response.getWriter();

        String jsonStr = JSONObject.toJSONString(orderData);
        out.println(jsonStr);
    }
}