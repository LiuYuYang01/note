package src.web;

import com.alibaba.fastjson.JSONObject;
import src.domain.User;
import src.service.UserService;
import src.service.impl.UserServicelmpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/user")
public class UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer uid = Integer.valueOf(request.getParameter("uid"));

        UserService userService = new UserServicelmpl();
        User userData = userService.info(uid);
        System.out.println(userData);

        response.setContentType("application/json; charset=utf8");

        PrintWriter out = response.getWriter();

        String jsonStr = JSONObject.toJSONString(userData);
        out.println(jsonStr);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uname =  request.getParameter("uname");
        System.out.println(uname);

        User user = new User(null, uname);

        UserService userService = new UserServicelmpl();
        userService.add(user);
    }
}
