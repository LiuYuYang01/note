package src.mapper;

import org.apache.ibatis.annotations.Select;
import src.domain.Order;

public interface OrderMapper {
    @Select("select * from `order` where oid = #{oid}")
    public Order info(Integer oid);
}
