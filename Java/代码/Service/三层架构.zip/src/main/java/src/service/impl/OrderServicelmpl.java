package src.service.impl;

import org.apache.ibatis.session.SqlSession;
import src.domain.Order;
import src.mapper.OrderMapper;
import src.service.OrderService;
import src.utils.MybatisUtils;

public class OrderServicelmpl implements OrderService {
    @Override
    public Order info(Integer id) {
        // 获取session
        SqlSession sqlSession = MybatisUtils.getSession();

        OrderMapper orderMapper = sqlSession.getMapper(OrderMapper.class);
        System.out.println(orderMapper);

        Order order = orderMapper.info(id);

        MybatisUtils.close(sqlSession);

        return order;
    }
}
