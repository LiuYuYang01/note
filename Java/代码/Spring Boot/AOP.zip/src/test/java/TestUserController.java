import liuyuyang.Main;
import liuyuyang.domain.User;
import liuyuyang.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

// spring和Junit进行整合（固定写法）
@RunWith(SpringRunner.class)
// 确定程序入口
@SpringBootTest(classes = Main.class)
public class TestUserController {
    @Resource
    private UserService userService;

    @Test
    public void run(){
        userService.add(new User("薛文宇"));

        User data = userService.info(2);

        List<User> list = userService.list();
        for (User user : list) {
            System.out.println(user);
        }
    }
}
