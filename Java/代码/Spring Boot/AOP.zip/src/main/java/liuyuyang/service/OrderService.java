package liuyuyang.service;

import liuyuyang.domain.Order;

import java.util.List;

public interface OrderService {
    public Order info(int id);

    public List<Order> list(int uid);
}
