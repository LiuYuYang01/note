package liuyuyang.mapper;

import liuyuyang.domain.Order;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface OrderMapper {
    @Select("select * from `order` where oid = #{oid}")
    public Order info(int id);

    @Select("select * from `order` where user_id = #{uid}")
    public List<Order> list(int uid);
}
