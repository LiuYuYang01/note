package liuyuyang;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@Aspect
public class TimeAspect {
    @Pointcut("execution(* liuyuyang.service.impl.*.*(..))")
    private void type() {}

    // 核心代码
    public void func(JoinPoint j, String status) {
        // 获取类名：liuyuyang.service.impl.UserServiceImpl
        String s = j.getTarget().getClass().getName();
        // 找出类名后面的"."下标
        int index = s.lastIndexOf(".");
        // 通过字符串截取出类名
        String c = s.substring(index + 1);

        // 获取方法名
        String m = j.getSignature().getName();

        // 获取当前时间
        LocalDateTime date = LocalDateTime.now();

        // 时间格式化
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss-SSS");
        System.out.printf("操作时间：%s 操作类：%s 操作方法 %s %s\n", f.format(date), c, m, status);
    }

    @Before("type()")
    public void logStart(JoinPoint j) {
        func(j,"开始执行");
    }

    @After("type()")
    public void logEnd(JoinPoint j) {
        func(j,"结束执行");
    }
}