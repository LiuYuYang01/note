package liuyuyang.service.impl;

import liuyuyang.mapper.UserMapper;
import liuyuyang.service.UserService;
import liuyuyang.domain.User;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserMapper userMapper;

    @Override
    public Integer add(User user) {
        Integer n = userMapper.add(user);
        System.out.println(n >= 1 ? "新增成功" : "新增失败");
        return n;
    }

    @Override
    public User info(int id) {
        System.out.println(userMapper.info(id));
        return userMapper.info(id);
    }

    @Override
    public List<User> list() {
        System.out.println(userMapper.list());
        return userMapper.list();
    }
}
