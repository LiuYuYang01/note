package liuyuyang.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class User {
    private Integer uid;
    private String uname;

    private List<Order> orderList;

    public User(String uname){
        this.uname = uname;
    }
}
