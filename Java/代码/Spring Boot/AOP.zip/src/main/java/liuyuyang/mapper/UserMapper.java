package liuyuyang.mapper;

import liuyuyang.domain.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {
    @Insert("insert into user(uname) values(#{uname})")
    public Integer add(User user);

    @Select("select * from user where uid = #{uid}")
    @Results({
            @Result(property = "uid", column = "uid"),
            @Result(property = "orderList", many = @Many(select = "liuyuyang.mapper.OrderMapper.list"), column = "uid")
    })
    public User info(int id);

    @Select("select * from user")
    @Results({
            @Result(property = "uid", column = "uid"),
            @Result(property = "orderList", many = @Many(select = "liuyuyang.mapper.OrderMapper.list"), column = "uid")
    })
    public List<User> list();
}
