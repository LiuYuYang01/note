package liuyuyang.service.impl;

import liuyuyang.domain.Order;
import liuyuyang.domain.User;
import liuyuyang.mapper.OrderMapper;
import liuyuyang.service.OrderService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class OrderServicelmpl implements OrderService {
    @Resource
    OrderMapper orderMapper;

    @Override
    public Order info(int id){
        System.out.println(orderMapper.info(id));
        return orderMapper.info(id);
    }

    @Override
    public List<Order> list(int uid){
        System.out.println(orderMapper.list(uid));
        return orderMapper.list(uid);
    }
}
