package liuyuyang;

import liuyuyang.service.UserService;
import liuyuyang.domain.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Main.class)
public class TestUser {
    @Resource
    private UserService userService;

    @Test
    public void run(){
        // 新增数据
        userService.add(new User(null, "zhangsan"));

        // 获取单个数据
        User data = userService.info(1);

        // 获取数据列表
        List<User> list = userService.list();
    }
}
