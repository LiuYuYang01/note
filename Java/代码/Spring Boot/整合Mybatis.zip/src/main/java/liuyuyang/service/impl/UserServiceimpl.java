package liuyuyang.service.impl;

import liuyuyang.domain.User;
import liuyuyang.mapper.UserMapper;
import liuyuyang.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserServiceimpl implements UserService {
    @Resource
    private UserMapper userMapper;

    @Override
    public Integer add(User user){
        // 在此文件中用于对数据的处理以及具体业务逻辑的实现
        return userMapper.add(user);
    }

    @Override
    public User info(Integer uid) {
        return userMapper.info(uid);
    }

    @Override
    public List<User> list(){
        return userMapper.list();
    }
}
