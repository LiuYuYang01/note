package liuyuyang.mapper;

import liuyuyang.domain.User;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {
    @Select("insert into user(uname) values(#{uname})")
    public Integer add(User user);

    @Select("select * from user where uid = #{uid}")
    public User info(Integer uid);

    @Select("select * from user")
    public List<User> list();
}
